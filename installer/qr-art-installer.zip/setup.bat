@echo off
REM 纸艺二维码 B 方案一键安装（Windows）
REM 安装包本身不含大模型；模型在安装时从 HuggingFace 下载（SD 1.5 + ControlNet QR，fp16 约 3GB）
REM 需要：Python 3.10+（勾选 Add to PATH）、联网、硬盘至少留 12GB；有 NVIDIA 显卡会快很多
setlocal
cd /d %~dp0

python --version >nul 2>&1
if errorlevel 1 (
  echo [错误] 没找到 python。先去 python.org 装 Python 3.10 以上，安装时勾选 Add Python to PATH。
  pause
  exit /b 1
)

echo [1/4] 建虚拟环境 .venv ...
python -m venv .venv
if errorlevel 1 (
  echo [错误] 建虚拟环境失败。
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat

echo [2/4] 升级 pip，装 torch ...
python -m pip install --upgrade pip
nvidia-smi >nul 2>&1
if errorlevel 1 (
  echo 没检测到 NVIDIA 显卡，装 CPU 版 torch（生成会很慢，一张 20-60 分钟，建议用 Kaggle/Colab 的免费 T4）。
  python -m pip install torch
) else (
  echo 检测到 NVIDIA 显卡，装 CUDA 版 torch。
  python -m pip install torch --index-url https://download.pytorch.org/whl/cu121
)
if errorlevel 1 (
  echo [错误] torch 安装失败，检查网络后重新双击 setup.bat。
  pause
  exit /b 1
)

echo [3/4] 装运行库 ...
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo [错误] 运行库安装失败，检查网络后重新双击 setup.bat。
  pause
  exit /b 1
)

echo [4/4] 下载模型（约 3GB，按网速要几分钟到几十分钟，断了可以重新跑，会断点续传）...
python download_models.py
if errorlevel 1 (
  echo [错误] 模型下载失败，检查网络后重新双击 setup.bat。
  pause
  exit /b 1
)

echo.
echo 安装完成！生成一张试试：
echo   .venv\Scripts\activate.bat
echo   python generate_qr.py --text "https://example.com" --style paperflower
echo 出图在 outputs 文件夹里，生成完会自动验扫，通过才算数。
pause
