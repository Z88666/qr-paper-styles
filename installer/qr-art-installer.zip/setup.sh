#!/bin/bash
# 纸艺二维码 B 方案一键安装（macOS / Linux）
# 安装包本身不含大模型；模型在安装时从 HuggingFace 下载（SD 1.5 + ControlNet QR，fp16 约 3GB）
# 需要：Python 3.10+、联网、硬盘至少留 12GB；有 NVIDIA 显卡会快很多
set -e
cd "$(dirname "$0")"

if ! command -v python3 >/dev/null 2>&1; then
  echo "[错误] 没找到 python3，先装 Python 3.10 以上。"
  exit 1
fi

echo "[1/4] 建虚拟环境 .venv ..."
python3 -m venv .venv
# shellcheck disable=SC1091
source .venv/bin/activate

echo "[2/4] 升级 pip，装 torch ..."
python -m pip install --upgrade pip
if command -v nvidia-smi >/dev/null 2>&1; then
  echo "检测到 NVIDIA 显卡，装 CUDA 版 torch。"
  python -m pip install torch --index-url https://download.pytorch.org/whl/cu121
else
  echo "没检测到 NVIDIA 显卡，装 CPU 版 torch（生成会很慢，一张 20-60 分钟，建议用 Kaggle/Colab 的免费 T4）。"
  python -m pip install torch
fi

echo "[3/4] 装运行库 ..."
python -m pip install -r requirements.txt

echo "[4/4] 下载模型（约 3GB，按网速要几分钟到几十分钟，断了可以重新跑，会断点续传）..."
python download_models.py

echo ""
echo "安装完成！生成一张试试："
echo "  source .venv/bin/activate"
echo "  python generate_qr.py --text \"https://example.com\" --style paperflower"
echo "出图在 outputs 文件夹里，生成完会自动验扫，通过才算数。"
